<html>
<body>

<!-- Using PHP inputed value from contactus.html and outputs on the PHP along with subsctiption confirmation -->
Welcome <?php echo $_POST["fname"]; ?><br>
Your address is: <?php echo $_POST["address"]; ?><br>
Your email is: <?php echo $_POST["email"]; ?>

<!-- Using PHP conditional statemement to validate if inputted value is a valid email address  -->
<?php
	if(filter_var($email, FILTER_VALIDATE_EMAIL)){ 
  		echo("$email is a valid");
	} else {
 		 echo("$email is not valid");
}
?>


</body>
</html> 