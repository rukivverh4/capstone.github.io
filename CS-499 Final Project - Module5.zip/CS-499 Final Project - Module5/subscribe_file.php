<html>
<body>

<!-- Using PHP inputed value from contactus.html and outputs on the PHP along with subsctiption confirmation -->
Welcome <?php echo $_POST["fname"]; ?><br>
Your address is: <?php echo $_POST["address"]; ?><br>
Your email is: <?php echo $_POST["email"]; ?>

<!-- Using PHP conditional statemement to validate and input data into userdata text file.  -->
<?php
 $path = 'userdata.txt';
 if (isset($_POST['fname']) && isset($_POST['address']) && isset($_POST['email'])) {
    $fh = fopen($path,"a+");
    $string = $_POST['fname'].' - '.$_POST['address'].' - '.$_POST['email'];
    fwrite($fh,$string); // Write information to text file
    fclose($fh); // Close
 }
?>


</body>
</html> 